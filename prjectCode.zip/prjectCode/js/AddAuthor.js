var AuthorViewModel=function(){
    var self=this;
    self.id=ko.observable("");
    self.name=ko.observable("");
    self.email=ko.observable("");
    self.dept=ko.observable("");
    self.web=ko.observable("");
    self.skill=ko.observable("");
    
    console.log(self.id);
    var update=function(){
        console.log(self.id);
    localStorage.setItem('id', self.id);
    localStorage.setItem('name', self.name);
    localStorage.setItem('email', self.email);
    localStorage.setItem('dept', self.dept);
    localStorage.setItem('web', self.web);
    localStorage.setItem('skill', self.skill);
}
    }

ko.applyBindings(AuthorViewModel);