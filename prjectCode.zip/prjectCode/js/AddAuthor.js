/*var AuthorViewModel=function(){
    var self=this;
    self.id=ko.observable("");
    self.name=ko.observable("");
    self.email=ko.observable("");
    self.dept=ko.observable("");
    self.web=ko.observable("");
    self.skill=ko.observable("");
    
    console.log(self.id());
    var update=function(){
        console.log(self.id());

    localStorage.setItem('id', self.id());
    localStorage.setItem('name', self.name());
    localStorage.setItem('email', self.email());
    localStorage.setItem('dept', self.dept());
    localStorage.setItem('web', self.web());
    localStorage.setItem('skill', self.skill());
};
    };

var vm=new AuthorViewModel();
ko.applyBindings(vm);*/


var form = {
    id: ko.observable(''),
    name: ko.observable(''),
    email: ko.observable(''),
    dept: ko.observable(''),
    web: ko.observable(''),
    skill:ko.observable(''),
    update: function() {
       /* alert("You entered:"
            + "\nFirstname: " + this.id()
            + "\nLastname: " + this.name()
            + "\nEmail: " + this.email()
            + "\nDept: " + this.dept()
            + "\nWebsite:\n" + this.web()
            + "\nSkills:\n" + this.skill());
        */
   /* localStorage.setItem('id', this.id());
    localStorage.setItem('name', this.name());
    localStorage.setItem('email', this.email());
    localStorage.setItem('dept', this.dept());
    localStorage.setItem('web', this.web());
    localStorage.setItem('skill', this.skill());*/
         window.location.href = "index.html";
        }
};

ko.applyBindings(form);