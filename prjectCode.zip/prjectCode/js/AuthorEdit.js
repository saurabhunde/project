var form = {
    name: ko.observable('Chetya'),
    email: ko.observable('chetya@gmail.com'),
    dept: ko.observable('FET HighIQ'),
    web: ko.observable('chetya.com'),
    skill: ko.observable('DJ wala'),
    formVisible:ko.observable(false),
    
    edit: function() {
       this.formVisible(!this.formVisible());
        },
    
    
};

ko.applyBindings(form);