var form = {
    isbn: ko.observable('123'),
    title: ko.observable('3 mistakes'),
    author: ko.observable('chetya'),
    price: ko.observable('350'),
    web: ko.observable('Flipkart'),
    formVisible:ko.observable(false),
    
    edit: function() {
       this.formVisible(!this.formVisible());
        },
    
    
};

ko.applyBindings(form);