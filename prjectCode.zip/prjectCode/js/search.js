function Book(isbn, bookTitle, authorName) {
    this.isbn = ko.observable(isbn);
    this.bookTitle = ko.observable(bookTitle);
    this.authorName = ko.observable(authorName);
}

function model() {
    var self = this;
   self.qnum=new RegExp("[0-9]");
   self.qchar=new RegExp("[a-zA-Z]");
    self.books = ko.observableArray("");
    self.query = ko.observable("");
    
    self.filteredBooks = ko.computed(function () {
        var filter = self.query().toLowerCase();

        if (!filter) {
            return self.books();
        } 
        else{
            console.log(filter);
            if(self.qnum.test(filter)){
                return ko.utils.arrayFilter(self.books(), function (item) {
                return item.isbn().toLowerCase().indexOf(filter) !== -1;
            });
            }
           if(self.qchar.test(filter)){
                return ko.utils.arrayFilter(self.books(), function (item) {
                return item.bookTitle().toLowerCase().indexOf(filter) !== -1;
                    });
            }
            
        }
    });
}

var mymodel = new model();

$(document).ready(function () {
    loaddata();
    ko.applyBindings(mymodel);
});

function loaddata() {
    mymodel.books.push(new Book("123", "Anna Karenina", "Leo Tolstoy"));
    mymodel.books.push(new Book("345", "War and Peace", "Leo Tolstoy"));
    mymodel.books.push(new Book("456", "The stories of Anton Chekhov", "Anna jane"));
}

$(document).ready(function(){
    
    mymodel.books.push(new Book(localStorage.getItem('isbn'), localStorage.getItem('title'), localStorage.getItem('author')));
    localStorage.clear();
  // alert(localStorage.getItem('id'));
    
});