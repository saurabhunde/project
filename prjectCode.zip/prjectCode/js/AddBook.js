var form = {
    isbn: ko.observable(''),
    title: ko.observable(''),
    author: ko.observable(''),
    price: ko.observable(''),
    web: ko.observable(''),
    
    update: function() {
     /*  alert("You entered:"
            + "\nFirstname: " + this.isbn());*/
       
    localStorage.setItem('isbn', this.isbn());
    localStorage.setItem('title', this.title());
    localStorage.setItem('author', this.author());
    localStorage.setItem('price', this.price());
    localStorage.setItem('web', this.web());
    
         window.location.href = "index.html";
        }
};

ko.applyBindings(form);